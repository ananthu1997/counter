<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_IN" sourcelanguage="kn_IN">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="59"/>
        <location filename="main.qml" line="60"/>
        <source>Hello World</source>
        <translation>ಹಲೋ ಪ್ರಪಂಚ</translation>
    </message>
    <message>
        <location filename="main.qml" line="61"/>
        <source>The QTranslator class provides internationalizationsupport for text output.An object of this class contains a set of translations from a source language to a target language. QTranslator provides functions to look up translations in a translation file. Translation files are created using Qt Linguist.</source>
        <translation>QTranslator ವರ್ಗವು ಪಠ್ಯ ಔಟ್ ಪುಟ್ ಗಾಗಿ ಇಂಟರ್ನ್ಯಾಷನಲೈಸೇಶನ್ ಬೆಂಬಲವನ್ನು ಒದಗಿಸುತ್ತದೆ. ಈ ವರ್ಗದ ಆಬ್ಜೆಕ್ಟ್ ಒಂದು ಮೂಲ ಭಾಷೆಯಿಂದ ಉದ್ದೇಶಿತ ಭಾಷೆಗೆ ಅನುವಾದಗಳ ಒಂದು ಸೆಟ್ ಅನ್ನು ಹೊಂದಿರುತ್ತದೆ. ಅನುವಾದ ಫೈಲ್ ನಲ್ಲಿ ಅನುವಾದಗಳನ್ನು ನೋಡಲು QTranslator ಫಂಕ್ಷನ್ ಗಳನ್ನು ಒದಗಿಸುತ್ತದೆ. Qt ಭಾಷಾಶಾಸ್ತ್ರಜ್ಞಬಳಸಿ ಅನುವಾದ ಫೈಲ್ ಗಳನ್ನು ರಚಿಸಲಾಗುತ್ತದೆ.</translation>
    </message>
</context>
</TS>
