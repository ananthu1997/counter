<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ml_IN">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="59"/>
        <location filename="main.qml" line="60"/>
        <source>Hello World</source>
        <translatorcomment>ഹലോ വേള്‍ഡ്</translatorcomment>
        <translation>ഹലോ വേള്‍ഡ്</translation>
    </message>
    <message>
        <location filename="main.qml" line="61"/>
        <source>The QTranslator class provides internationalizationsupport for text output.An object of this class contains a set of translations from a source language to a target language. QTranslator provides functions to look up translations in a translation file. Translation files are created using Qt Linguist.</source>
        <translatorcomment>ടെക്സ്റ്റ് ഔട്ട്പുട്ടിനായി ക്യുട്രാൻസ്ലേറ്റർ ക്ലാസ് അന്താരാഷ്ട്രവൽക്കരണ പിന്തുണ നൽകുന്നു. ഈ ക്ലാസ്സിന്റെ ഒരു വസ്തുവിൽ ഒരു ഉറവിട ഭാഷയിൽ നിന്ന് ടാർഗറ്റ് ഭാഷയിലേക്കുള്ള പരിഭാഷകളുടെ ഒരു കൂട്ടം അടങ്ങിയിരിക്കുന്നു. ഒരു വിവർത്തന ഫയലിൽ പരിഭാഷകൾ പരിശോധിക്കുന്നതിനുള്ള പ്രവർത്തനങ്ങൾ ക്യുട്രാൻസ്ലേറ്റർ നൽകുന്നു. ക്യുടി ഭാഷാശാസ്ത്രജ്ഞനെ ഉപയോഗിച്ചാണ് വിവർത്തന ഫയലുകൾ സൃഷ്ടിക്കുന്നത്.</translatorcomment>
        <translation>ടെക്സ്റ്റ് ഔട്ട്പുട്ടിനായി ക്യുട്രാൻസ്ലേറ്റർ ക്ലാസ് അന്താരാഷ്ട്രവൽക്കരണ പിന്തുണ നൽകുന്നു. ഈ ക്ലാസ്സിന്റെ ഒരു വസ്തുവിൽ ഒരു ഉറവിട ഭാഷയിൽ നിന്ന് ടാർഗറ്റ് ഭാഷയിലേക്കുള്ള പരിഭാഷകളുടെ ഒരു കൂട്ടം അടങ്ങിയിരിക്കുന്നു. ഒരു വിവർത്തന ഫയലിൽ പരിഭാഷകൾ പരിശോധിക്കുന്നതിനുള്ള പ്രവർത്തനങ്ങൾ ക്യുട്രാൻസ്ലേറ്റർ നൽകുന്നു. ക്യുടി ഭാഷാശാസ്ത്രജ്ഞനെ ഉപയോഗിച്ചാണ് വിവർത്തന ഫയലുകൾ സൃഷ്ടിക്കുന്നത്.</translation>
    </message>
</context>
</TS>
